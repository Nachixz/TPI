import controlador.ControladorGimnasio;
import vista.VistaConsola;

public class Main {
    public static void main(String[] args) {
        VistaConsola vista = new VistaConsola();
        ControladorGimnasio controlador = new ControladorGimnasio(vista);
        controlador.iniciar();
    }
}
