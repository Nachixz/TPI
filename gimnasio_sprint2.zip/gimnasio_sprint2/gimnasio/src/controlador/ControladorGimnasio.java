package controlador;

import java.io.IOException;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.List;

import modelo.Asistencia;
import modelo.Entrenador;
import modelo.EstadoMembresia;
import modelo.EstadoPlan;
import modelo.Gimnasio;
import modelo.Membresia;
import modelo.Plan;
import modelo.Socio;
import modelo.Validador;
import repositorio.RepositorioArchivo;
import repositorio.RepositorioAsistencias;
import repositorio.RepositorioEntrenadores;
import repositorio.RepositorioMembresias;
import repositorio.RepositorioPlanes;
import repositorio.RepositorioSocios;
import vista.VistaConsola;

public class ControladorGimnasio {
    private VistaConsola vista;
    private Gimnasio gimnasio;
    private RepositorioSocios repositorioSocios;
    private RepositorioPlanes repositorioPlanes;
    private RepositorioEntrenadores repositorioEntrenadores;
    private RepositorioMembresias repositorioMembresias;
    private RepositorioAsistencias repositorioAsistencias;

    public ControladorGimnasio(VistaConsola vista) {
        this.vista = vista;
        this.gimnasio = new Gimnasio();
        this.repositorioSocios = new RepositorioSocios("socios.csv");
        this.repositorioPlanes = new RepositorioPlanes("planes.csv");
        this.repositorioEntrenadores = new RepositorioEntrenadores("entrenadores.csv");
        this.repositorioMembresias = new RepositorioMembresias("membresias.csv");
        this.repositorioAsistencias = new RepositorioAsistencias("asistencias.csv");
    }

    public void iniciar() {
        if (cargarDatos() == false) {
            return;
        }

        int opcion = -1;
        while (opcion != 0) {
            vista.mostrarMenu();
            opcion = vista.leerEntero("Opcion: ");

            switch (opcion) {
                case 1: registrarSocio(); break;
                case 2: consultarSocio(); break;
                case 3: modificarSocio(); break;
                case 4: verPlanes(); break;
                case 5: cargarPlan(); break;
                case 6: modificarPlan(); break;
                case 7: contratarMembresia(); break;
                case 8: renovarMembresia(); break;
                case 9: suspenderOReactivarMembresia(); break;
                case 10: registrarEntrada(); break;
                case 11: registrarSalida(); break;
                case 12: cancelarAsistencia(); break;
                case 13: registrarEntrenador(); break;
                case 14: verEntrenadores(); break;
                case 15: buscarPorObjetivo(); break;
                case 0: break;
                default: vista.mostrarMensaje("Opcion invalida.");
            }
        }
    }

    // ---------- carga y guardado de los archivos ----------

    // devuelve false si no se pudieron leer los archivos
    private boolean cargarDatos() {
        boolean primeraVez = false;
        try {
            for (Plan p : repositorioPlanes.leerTodos()) {
                gimnasio.agregarPlan(p);
            }
            for (Entrenador e : repositorioEntrenadores.leerTodos()) {
                gimnasio.agregarEntrenador(e);
            }
            for (Socio s : repositorioSocios.leerTodos()) {
                if (gimnasio.buscarSocio(s.getDni()) == null) {
                    gimnasio.agregarSocio(s);
                }
            }

            primeraVez = gimnasio.estaVacio();

            // si falta el archivo de planes se vuelven a cargar los planes iniciales,
            // porque las membresias necesitan encontrar su plan
            if (gimnasio.getPlanes().isEmpty()) {
                cargarPlanesIniciales();
            }

            repositorioMembresias.cargar(gimnasio);
            repositorioAsistencias.cargar(gimnasio);
        } catch (IOException e) {
            // si se siguiera, al guardar se pisarian los archivos con datos incompletos
            vista.mostrarMensaje("ERROR: no se pudieron leer los archivos de datos.");
            vista.mostrarMensaje("El programa se cierra para no perder informacion.");
            return false;
        }

        avisarLineasInvalidas(repositorioPlanes);
        avisarLineasInvalidas(repositorioEntrenadores);
        avisarLineasInvalidas(repositorioSocios);
        avisarLineasInvalidas(repositorioMembresias);
        avisarLineasInvalidas(repositorioAsistencias);

        // la primera vez no hay archivos, entonces se cargan los datos de prueba
        if (primeraVez) {
            cargarDatosDePrueba();
        }
        guardarDatos();
        return true;
    }

    private void avisarLineasInvalidas(RepositorioArchivo repositorio) {
        if (repositorio.getLineasInvalidas() > 0) {
            vista.mostrarMensaje("AVISO: en " + repositorio.getArchivo() + " habia "
                    + repositorio.getLineasInvalidas() + " linea(s) con errores que no se cargaron.");
            try {
                repositorio.hacerCopiaDeSeguridad();
                vista.mostrarMensaje("Se guardo una copia del archivo original en "
                        + repositorio.getArchivo() + ".bak");
            } catch (IOException e) {
                vista.mostrarMensaje("No se pudo hacer la copia de seguridad del archivo.");
            }
        }
    }

    private void guardarDatos() {
        try {
            repositorioPlanes.guardarTodos(gimnasio.getPlanes());
            repositorioEntrenadores.guardarTodos(gimnasio.getEntrenadores());
            repositorioSocios.guardarTodos(gimnasio.getSocios());
            repositorioMembresias.guardarTodas(gimnasio.getSocios());
            repositorioAsistencias.guardarTodas(gimnasio.getSocios());
        } catch (IOException e) {
            vista.mostrarMensaje("ERROR: no se pudieron guardar los datos en los archivos.");
        }
    }

    // ---------- pedir datos validados ----------

    private String pedirTexto(String mensaje) {
        String texto = vista.leerTexto(mensaje);
        while (Validador.esTextoValido(texto) == false) {
            vista.mostrarMensaje("Este dato no puede quedar vacio.");
            texto = vista.leerTexto(mensaje);
        }
        return texto;
    }

    private String pedirNombre(String mensaje) {
        String nombre = vista.leerTexto(mensaje);
        while (Validador.esNombreValido(nombre) == false) {
            vista.mostrarMensaje("No puede quedar vacio y solo puede tener letras.");
            nombre = vista.leerTexto(mensaje);
        }
        return nombre;
    }

    private int pedirDni(String mensaje) {
        int dni = vista.leerEntero(mensaje);
        while (Validador.esDniValido(dni) == false) {
            vista.mostrarMensaje("El DNI tiene que tener 7 u 8 numeros.");
            dni = vista.leerEntero(mensaje);
        }
        return dni;
    }

    private String pedirTelefono(String mensaje) {
        String telefono = vista.leerTexto(mensaje);
        while (Validador.esTelefonoValido(telefono) == false) {
            vista.mostrarMensaje("El telefono solo puede tener numeros (entre 6 y 15).");
            telefono = vista.leerTexto(mensaje);
        }
        return telefono;
    }

    private String pedirEmail(String mensaje) {
        String email = vista.leerTexto(mensaje);
        while (Validador.esEmailValido(email) == false) {
            vista.mostrarMensaje("El email no es valido. Ejemplo: nombre@mail.com");
            email = vista.leerTexto(mensaje);
        }
        return email;
    }

    private LocalDate pedirFechaNacimiento() {
        LocalDate fecha = null;
        while (fecha == null) {
            int dia = vista.leerEntero("Dia de nacimiento: ");
            int mes = vista.leerEntero("Mes de nacimiento: ");
            int anio = vista.leerEntero("Anio de nacimiento: ");
            try {
                fecha = LocalDate.of(anio, mes, dia);
                if (Validador.esFechaNacimientoValida(fecha) == false) {
                    vista.mostrarMensaje("La fecha de nacimiento no puede ser futura ni tan antigua.");
                    fecha = null;
                }
            } catch (DateTimeException e) {
                vista.mostrarMensaje("Esa fecha no existe.");
            }
        }
        return fecha;
    }

    private double pedirHora(String mensaje, double horaMaxima) {
        double hora = vista.leerDecimal(mensaje);
        while (hora < 0 || hora > horaMaxima) {
            vista.mostrarMensaje("La hora tiene que estar entre 0 y " + horaMaxima);
            hora = vista.leerDecimal(mensaje);
        }
        return hora;
    }

    private double pedirPrecio(String mensaje) {
        double precio = vista.leerDecimal(mensaje);
        while (precio <= 0) {
            vista.mostrarMensaje("El precio tiene que ser mayor a cero.");
            precio = vista.leerDecimal(mensaje);
        }
        return precio;
    }

    private Socio pedirSocio() {
        Socio s = gimnasio.buscarSocio(vista.leerEntero("DNI del socio: "));
        if (s == null) {
            vista.mostrarMensaje("No existe un socio con ese DNI.");
        }
        return s;
    }

    // ---------- socios ----------

    private void registrarSocio() {
        int dni = pedirDni("DNI: ");
        if (gimnasio.buscarSocio(dni) != null) {
            vista.mostrarMensaje("Ya existe un socio con ese DNI.");
            return;
        }
        String nombre = pedirNombre("Nombre: ");
        String apellido = pedirNombre("Apellido: ");
        String telefono = pedirTelefono("Telefono: ");
        String email = pedirEmail("Email: ");
        LocalDate nacimiento = pedirFechaNacimiento();
        String objetivo = vista.elegirDeLista("Objetivo:", Socio.OBJETIVOS);

        int id = gimnasio.siguienteIdSocio();
        gimnasio.agregarSocio(new Socio(id, nombre, apellido, dni, telefono, email, nacimiento, objetivo));
        guardarDatos();
        vista.mostrarMensaje("Socio registrado.");
    }

    private void consultarSocio() {
        Socio s = pedirSocio();
        if (s == null) {
            return;
        }
        vista.mostrarMensaje(s.obtenerDatos());

        if (s.getMembresiaActual() == null) {
            vista.mostrarMensaje("Membresia: no tiene");
        } else {
            s.tieneMembresiaVigente();
            vista.mostrarMensaje("Membresia: " + s.getMembresiaActual().obtenerMembresia());
        }

        vista.mostrarMensaje("Membresias anteriores: " + s.getMembresiasAnteriores().size());
        for (Membresia m : s.getMembresiasAnteriores()) {
            vista.mostrarMensaje("  " + m.obtenerMembresia());
        }

        vista.mostrarMensaje("Asistencias: " + s.getAsistencias().size());
        for (Asistencia a : s.getAsistencias()) {
            vista.mostrarMensaje("  " + a.obtenerAsistencia());
        }
    }

    private void modificarSocio() {
        Socio s = pedirSocio();
        if (s == null) {
            return;
        }
        vista.mostrarMensaje(s.obtenerDatos());

        String[] datos = {"Nombre", "Apellido", "Telefono", "Email", "Fecha de nacimiento", "Objetivo"};
        int posicion = vista.elegirPosicion("Que dato queres modificar?", datos);

        switch (posicion) {
            case 0: s.setNombre(pedirNombre("Nuevo nombre: ")); break;
            case 1: s.setApellido(pedirNombre("Nuevo apellido: ")); break;
            case 2: s.setTelefono(pedirTelefono("Nuevo telefono: ")); break;
            case 3: s.setEmail(pedirEmail("Nuevo email: ")); break;
            case 4: s.setFechaNacimiento(pedirFechaNacimiento()); break;
            case 5: s.setObjetivo(vista.elegirDeLista("Nuevo objetivo:", Socio.OBJETIVOS)); break;
        }
        guardarDatos();
        vista.mostrarMensaje("Datos actualizados.");
    }

    // ---------- planes ----------

    private void verPlanes() {
        for (Plan p : gimnasio.getPlanes()) {
            vista.mostrarMensaje(p.obtenerDatos());
        }
    }

    private void cargarPlan() {
        String nombre = pedirTexto("Nombre del plan: ");
        String cantidadSemana = pedirTexto("Veces por semana (ej: 3 veces o Libre): ");
        int duracion = vista.leerEntero("Duracion en dias: ");
        while (duracion <= 0) {
            vista.mostrarMensaje("La duracion tiene que ser mayor a cero.");
            duracion = vista.leerEntero("Duracion en dias: ");
        }
        double precio = pedirPrecio("Precio: ");

        int id = gimnasio.siguienteIdPlan();
        gimnasio.agregarPlan(new Plan(id, nombre, cantidadSemana, duracion, precio));
        guardarDatos();
        vista.mostrarMensaje("Plan cargado con el numero " + id + ".");
    }

    private void modificarPlan() {
        verPlanes();
        Plan p = gimnasio.buscarPlan(vista.leerEntero("Numero de plan: "));
        if (p == null) {
            vista.mostrarMensaje("No existe ese plan.");
            return;
        }

        String[] datos = {"Precio", "Disponibilidad"};
        int posicion = vista.elegirPosicion("Que queres modificar?", datos);

        if (posicion == 0) {
            p.cambiarPrecio(pedirPrecio("Nuevo precio: "));
        } else if (p.getEstado() == EstadoPlan.DISPONIBLE) {
            p.cambiarEstado(EstadoPlan.NO_DISPONIBLE);
        } else {
            p.cambiarEstado(EstadoPlan.DISPONIBLE);
        }
        guardarDatos();
        vista.mostrarMensaje("Plan actualizado: " + p.obtenerDatos());
    }

    // ---------- membresias ----------

    private void contratarMembresia() {
        Socio s = pedirSocio();
        if (s == null) {
            return;
        }

        // no se puede contratar otra si ya tiene una activa o suspendida, para no pisarla
        if (s.tieneMembresiaVigente()) {
            vista.mostrarMensaje("El socio ya tiene una membresia vigente: "
                    + s.getMembresiaActual().obtenerMembresia());
            vista.mostrarMensaje("Si quiere seguir, hay que renovarla (opcion 8).");
            return;
        }
        if (s.getMembresiaActual() != null
                && s.getMembresiaActual().getEstado() == EstadoMembresia.SUSPENDIDA) {
            vista.mostrarMensaje("El socio tiene una membresia suspendida. Hay que reactivarla (opcion 9).");
            return;
        }

        verPlanes();
        Plan p = gimnasio.buscarPlan(vista.leerEntero("Numero de plan: "));
        if (p == null) {
            vista.mostrarMensaje("No existe ese plan.");
            return;
        }
        if (p.getEstado() != EstadoPlan.DISPONIBLE) {
            vista.mostrarMensaje("Ese plan no esta disponible.");
            return;
        }
        s.contratarMembresia(p, LocalDate.now());
        guardarDatos();
        vista.mostrarMensaje("Membresia contratada: " + s.getMembresiaActual().obtenerMembresia());
    }

    private void renovarMembresia() {
        Socio s = pedirSocio();
        if (s == null) {
            return;
        }
        Membresia m = s.getMembresiaActual();
        if (m == null) {
            vista.mostrarMensaje("El socio no tiene membresia. Hay que contratar una (opcion 7).");
            return;
        }
        s.tieneMembresiaVigente();
        if (m.getEstado() == EstadoMembresia.SUSPENDIDA) {
            vista.mostrarMensaje("La membresia esta suspendida. Hay que reactivarla primero (opcion 9).");
            return;
        }
        if (m.getPlan().getEstado() != EstadoPlan.DISPONIBLE) {
            vista.mostrarMensaje("El plan de esta membresia ya no esta disponible, no se puede renovar.");
            return;
        }
        m.renovar();
        guardarDatos();
        vista.mostrarMensaje("Membresia renovada: " + m.obtenerMembresia());
    }

    private void suspenderOReactivarMembresia() {
        Socio s = pedirSocio();
        if (s == null) {
            return;
        }
        Membresia m = s.getMembresiaActual();
        if (m == null) {
            vista.mostrarMensaje("El socio no tiene membresia.");
            return;
        }
        s.tieneMembresiaVigente();

        if (m.getEstado() == EstadoMembresia.ACTIVA) {
            m.suspender();
            vista.mostrarMensaje("Membresia suspendida: " + m.obtenerMembresia());
        } else if (m.getEstado() == EstadoMembresia.SUSPENDIDA) {
            m.reactivar();
            vista.mostrarMensaje("Membresia reactivada: " + m.obtenerMembresia());
        } else {
            vista.mostrarMensaje("La membresia esta vencida. Hay que renovarla (opcion 8).");
        }
        guardarDatos();
    }

    // ---------- asistencias ----------

    private void registrarEntrada() {
        Socio s = pedirSocio();
        if (s == null) {
            return;
        }
        LocalDate hoy = LocalDate.now();

        if (s.tieneMembresiaVigente() == false) {
            vista.mostrarMensaje("No se puede registrar: la membresia no esta vigente.");
            guardarDatos();
            return;
        }
        if (s.buscarAsistenciaAbierta(hoy) != null) {
            vista.mostrarMensaje("El socio ya tiene una entrada de hoy sin salida. "
                    + "Primero hay que registrar la salida (opcion 11).");
            return;
        }

        double hora = pedirHora("Hora de entrada (ej: 18 o 18.5): ", 23.99);

        // el socio no elige entrenador: le toca el que esta de turno a esa hora
        Entrenador entrenador = gimnasio.buscarEntrenadorEnTurno(hora);

        s.registrarAsistencia(hoy, hora, entrenador);
        guardarDatos();

        vista.mostrarMensaje("Asistencia registrada.");
        if (entrenador == null) {
            vista.mostrarMensaje("A esa hora no hay ningun entrenador de turno.");
        } else {
            vista.mostrarMensaje("Entrenador asignado: " + entrenador.getNombre()
                    + " | Objetivo del socio: " + s.getObjetivo());
        }
    }

    private void registrarSalida() {
        Socio s = pedirSocio();
        if (s == null) {
            return;
        }
        Asistencia a = s.buscarAsistenciaAbierta(LocalDate.now());
        if (a == null) {
            vista.mostrarMensaje("El socio no tiene una entrada de hoy sin salida.");
            return;
        }
        vista.mostrarMensaje(a.obtenerAsistencia());

        double hora = pedirHora("Hora de salida: ", 24);
        if (hora <= a.getHoraEntrada()) {
            vista.mostrarMensaje("La salida tiene que ser despues de la entrada. No se registro.");
            return;
        }
        a.setHoraSalida(hora);
        guardarDatos();
        vista.mostrarMensaje("Salida registrada: " + a.obtenerAsistencia());
    }

    private void cancelarAsistencia() {
        Socio s = pedirSocio();
        if (s == null) {
            return;
        }
        List<Asistencia> asistencias = s.getAsistencias();
        if (asistencias.isEmpty()) {
            vista.mostrarMensaje("El socio no tiene asistencias.");
            return;
        }
        for (int i = 0; i < asistencias.size(); i++) {
            vista.mostrarMensaje((i + 1) + ". " + asistencias.get(i).obtenerAsistencia());
        }
        int numero = vista.leerEntero("Numero de asistencia a cancelar (0 para volver): ");
        if (numero == 0) {
            return;
        }
        if (numero < 1 || numero > asistencias.size()) {
            vista.mostrarMensaje("No existe esa asistencia.");
            return;
        }
        asistencias.get(numero - 1).cancelarAsistencia();
        guardarDatos();
        vista.mostrarMensaje("Asistencia cancelada.");
    }

    // ---------- entrenadores ----------

    private void registrarEntrenador() {
        int dni = pedirDni("DNI: ");
        if (gimnasio.buscarEntrenadorPorDni(dni) != null) {
            vista.mostrarMensaje("Ya existe un entrenador con ese DNI.");
            return;
        }
        String nombre = pedirNombre("Nombre y apellido: ");
        String telefono = pedirTelefono("Telefono: ");
        String email = pedirEmail("Email: ");
        double horaInicio = pedirHora("Hora en que empieza el turno (ej: 8): ", 24);
        double horaFin = pedirHora("Hora en que termina el turno (ej: 14): ", 24);

        if (horaInicio >= horaFin) {
            vista.mostrarMensaje("El turno tiene que empezar antes de terminar. No se registro el entrenador.");
            return;
        }
        // no puede haber dos entrenadores a la misma hora, porque no se sabria cual asignar
        Entrenador otro = gimnasio.buscarEntrenadorSuperpuesto(horaInicio, horaFin);
        if (otro != null) {
            vista.mostrarMensaje("Ese turno se pisa con el de otro entrenador: " + otro.obtenerDatos());
            vista.mostrarMensaje("No se registro el entrenador.");
            return;
        }

        int id = gimnasio.siguienteIdEntrenador();
        gimnasio.agregarEntrenador(new Entrenador(id, nombre, dni, telefono, email, horaInicio, horaFin));
        guardarDatos();
        vista.mostrarMensaje("Entrenador registrado.");
    }

    private void verEntrenadores() {
        for (Entrenador e : gimnasio.getEntrenadores()) {
            vista.mostrarMensaje(e.obtenerDatos());
        }
    }

    private void buscarPorObjetivo() {
        verEntrenadores();
        Entrenador e = gimnasio.buscarEntrenador(vista.leerEntero("Numero de entrenador: "));
        if (e == null) {
            vista.mostrarMensaje("No existe ese entrenador.");
            return;
        }
        String objetivo = vista.elegirDeLista("Objetivo a buscar:", Socio.OBJETIVOS);

        List<Socio> lista = e.hacerRutinas(gimnasio.getSocios(), objetivo);
        if (lista.isEmpty()) {
            vista.mostrarMensaje("Ese entrenador no atendio socios con ese objetivo.");
        }
        for (Socio s : lista) {
            vista.mostrarMensaje(s.obtenerDatos());
        }
    }

    // ---------- datos iniciales ----------

    private void cargarPlanesIniciales() {
        gimnasio.agregarPlan(new Plan(1, "Mensual libre", "Libre", 30, 25000));
        gimnasio.agregarPlan(new Plan(2, "Mensual 3 veces", "3 veces", 30, 18000));
        gimnasio.agregarPlan(new Plan(3, "Trimestral libre", "Libre", 90, 65000));
    }

    private void cargarDatosDePrueba() {
        gimnasio.agregarEntrenador(new Entrenador(1, "Carla Sosa", 35111000, "353499999", "carla@gym.com", 7, 12));
        gimnasio.agregarEntrenador(new Entrenador(2, "Diego Ruiz", 33222000, "353488888", "diego@gym.com", 12, 17));
        gimnasio.agregarEntrenador(new Entrenador(3, "Pablo Luna", 36333000, "353477777", "pablo@gym.com", 17, 22));

        Socio s1 = new Socio(1, "Juan", "Perez", 40111222, "353411111", "juan@mail.com",
                LocalDate.of(1998, 5, 10), "Ganar masa muscular");
        Socio s2 = new Socio(2, "Lucia", "Gomez", 41222333, "353422222", "lucia@mail.com",
                LocalDate.of(2001, 9, 3), "Bajar de peso");
        Socio s3 = new Socio(3, "Martin", "Diaz", 39333444, "353433333", "martin@mail.com",
                LocalDate.of(1995, 1, 22), "Ganar masa muscular");
        gimnasio.agregarSocio(s1);
        gimnasio.agregarSocio(s2);
        gimnasio.agregarSocio(s3);

        s1.contratarMembresia(gimnasio.buscarPlan(1), LocalDate.now());
        s2.contratarMembresia(gimnasio.buscarPlan(2), LocalDate.now().minusDays(10));
        s3.contratarMembresia(gimnasio.buscarPlan(2), LocalDate.now().minusDays(45));

        // asistencias de ayer, ya con la hora de salida
        LocalDate ayer = LocalDate.now().minusDays(1);
        Asistencia a1 = new Asistencia(s1, ayer, 9, 10.5, gimnasio.buscarEntrenadorEnTurno(9));
        a1.registrarAsistencia();
        Asistencia a2 = new Asistencia(s2, ayer, 18.5, 20, gimnasio.buscarEntrenadorEnTurno(18.5));
        a2.registrarAsistencia();
    }
}
