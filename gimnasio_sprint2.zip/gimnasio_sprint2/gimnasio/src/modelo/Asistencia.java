package modelo;

import java.time.LocalDate;

public class Asistencia {
    private Socio socio;
    private LocalDate fecha;
    private double horaEntrada;
    private double horaSalida;
    private Entrenador entrenador;

    public Asistencia(Socio socio, LocalDate fecha, double horaEntrada, Entrenador entrenador) {
        this.socio = socio;
        this.fecha = fecha;
        this.horaEntrada = horaEntrada;
        this.horaSalida = 0;
        this.entrenador = entrenador;
    }

    public Asistencia(Socio socio, LocalDate fecha, double horaEntrada, double horaSalida,
                      Entrenador entrenador) {
        this.socio = socio;
        this.fecha = fecha;
        this.horaEntrada = horaEntrada;
        this.horaSalida = horaSalida;
        this.entrenador = entrenador;
    }

    public void registrarAsistencia() {
        socio.getAsistencias().add(this);
    }

    public void cancelarAsistencia() {
        socio.getAsistencias().remove(this);
    }

    // la hora de salida queda en 0 hasta que el socio se va
    public boolean tieneSalida() {
        return horaSalida > 0;
    }

    public String obtenerAsistencia() {
        String nombreEntrenador = "sin entrenador";
        if (entrenador != null) {
            nombreEntrenador = entrenador.getNombre();
        }
        String salida = "sin registrar";
        if (tieneSalida()) {
            salida = "" + horaSalida;
        }
        return "Fecha: " + fecha + " | Entrada: " + horaEntrada + " | Salida: " + salida
                + " | Entrenador: " + nombreEntrenador;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public double getHoraEntrada() {
        return horaEntrada;
    }

    public Entrenador getEntrenador() {
        return entrenador;
    }

    public void setHoraSalida(double horaSalida) {
        this.horaSalida = horaSalida;
    }

    public String convertirALineaArchivo() {
        int idEntrenador = 0;
        if (entrenador != null) {
            idEntrenador = entrenador.getIdEntrenador();
        }
        return socio.getDni() + ";" + fecha + ";" + horaEntrada + ";" + horaSalida
                + ";" + idEntrenador;
    }
}
