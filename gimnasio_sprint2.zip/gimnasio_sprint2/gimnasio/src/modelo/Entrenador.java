package modelo;

import java.util.ArrayList;
import java.util.List;

public class Entrenador {
    private String nombre;
    private int dni;
    private String telefono;
    private int idEntrenador;
    private String email;
    private double horaInicio;
    private double horaFin;

    public Entrenador(int idEntrenador, String nombre, int dni, String telefono, String email,
                      double horaInicio, double horaFin) {
        this.idEntrenador = idEntrenador;
        this.nombre = nombre;
        this.dni = dni;
        this.telefono = telefono;
        this.email = email;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
    }

    public boolean estaEnTurno(double hora) {
        return hora >= horaInicio && hora < horaFin;
    }

    public boolean seSuperponeCon(double otraHoraInicio, double otraHoraFin) {
        return otraHoraInicio < horaFin && otraHoraFin > horaInicio;
    }

    public List<Socio> hacerRutinas(List<Socio> socios, String objetivo) {
        List<Socio> resultado = new ArrayList<>();
        for (Socio s : socios) {
            if (s.fueAtendidoPor(this) && s.getObjetivo().equalsIgnoreCase(objetivo)) {
                resultado.add(s);
            }
        }
        return resultado;
    }

    public String obtenerDatos() {
        return idEntrenador + " - " + nombre + " | DNI: " + dni + " | Tel: " + telefono
                + " | Email: " + email + " | Turno: de " + horaInicio + " a " + horaFin;
    }

    public int getIdEntrenador() {
        return idEntrenador;
    }

    public String getNombre() {
        return nombre;
    }

    public int getDni() {
        return dni;
    }

    public String convertirALineaArchivo() {
        return idEntrenador + ";" + nombre + ";" + dni + ";" + telefono + ";" + email
                + ";" + horaInicio + ";" + horaFin;
    }

    public static Entrenador crearDesdeLinea(String linea) {
        String[] datos = linea.split(";");

        int idEntrenador = Integer.parseInt(datos[0]);
        String nombre = datos[1];
        int dni = Integer.parseInt(datos[2]);
        String telefono = datos[3];
        String email = datos[4];
        double horaInicio = Double.parseDouble(datos[5]);
        double horaFin = Double.parseDouble(datos[6]);

        return new Entrenador(idEntrenador, nombre, dni, telefono, email, horaInicio, horaFin);
    }
}
