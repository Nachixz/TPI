package modelo;

public enum EstadoMembresia {
    ACTIVA,
    VENCIDA,
    SUSPENDIDA
}
