package modelo;

public enum EstadoPlan {
    DISPONIBLE,
    NO_DISPONIBLE
}
