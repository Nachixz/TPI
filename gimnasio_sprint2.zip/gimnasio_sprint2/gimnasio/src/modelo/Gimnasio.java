package modelo;

import java.util.ArrayList;
import java.util.List;

public class Gimnasio {
    private List<Socio> socios;
    private List<Plan> planes;
    private List<Entrenador> entrenadores;

    public Gimnasio() {
        this.socios = new ArrayList<>();
        this.planes = new ArrayList<>();
        this.entrenadores = new ArrayList<>();
    }

    public void agregarSocio(Socio socio) {
        socios.add(socio);
    }

    public void agregarPlan(Plan plan) {
        planes.add(plan);
    }

    public void agregarEntrenador(Entrenador entrenador) {
        entrenadores.add(entrenador);
    }

    public Socio buscarSocio(int dni) {
        for (Socio s : socios) {
            if (s.getDni() == dni) {
                return s;
            }
        }
        return null;
    }

    public Plan buscarPlan(int idPlan) {
        for (Plan p : planes) {
            if (p.getIdPlan() == idPlan) {
                return p;
            }
        }
        return null;
    }

    public Entrenador buscarEntrenador(int idEntrenador) {
        for (Entrenador e : entrenadores) {
            if (e.getIdEntrenador() == idEntrenador) {
                return e;
            }
        }
        return null;
    }

    public Entrenador buscarEntrenadorPorDni(int dni) {
        for (Entrenador e : entrenadores) {
            if (e.getDni() == dni) {
                return e;
            }
        }
        return null;
    }

    // el socio no elige entrenador: le toca el que esta de turno a esa hora
    public Entrenador buscarEntrenadorEnTurno(double hora) {
        for (Entrenador e : entrenadores) {
            if (e.estaEnTurno(hora)) {
                return e;
            }
        }
        return null;
    }

    public Entrenador buscarEntrenadorSuperpuesto(double horaInicio, double horaFin) {
        for (Entrenador e : entrenadores) {
            if (e.seSuperponeCon(horaInicio, horaFin)) {
                return e;
            }
        }
        return null;
    }

    // se busca el numero mas alto y se le suma 1, asi nunca se repite un numero
    public int siguienteIdSocio() {
        int mayor = 0;
        for (Socio s : socios) {
            if (s.getIdSocio() > mayor) {
                mayor = s.getIdSocio();
            }
        }
        return mayor + 1;
    }

    public int siguienteIdPlan() {
        int mayor = 0;
        for (Plan p : planes) {
            if (p.getIdPlan() > mayor) {
                mayor = p.getIdPlan();
            }
        }
        return mayor + 1;
    }

    public int siguienteIdEntrenador() {
        int mayor = 0;
        for (Entrenador e : entrenadores) {
            if (e.getIdEntrenador() > mayor) {
                mayor = e.getIdEntrenador();
            }
        }
        return mayor + 1;
    }

    public boolean estaVacio() {
        return socios.isEmpty() && planes.isEmpty() && entrenadores.isEmpty();
    }

    public List<Socio> getSocios() {
        return socios;
    }

    public List<Plan> getPlanes() {
        return planes;
    }

    public List<Entrenador> getEntrenadores() {
        return entrenadores;
    }
}
