package modelo;

import java.time.LocalDate;

public class Membresia {
    private Socio socio;
    private Plan plan;
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private EstadoMembresia estado;

    public Membresia(Socio socio, Plan plan, LocalDate fechaInicio) {
        this.socio = socio;
        this.plan = plan;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaInicio.plusDays(plan.getDuracionDias());
        this.estado = EstadoMembresia.ACTIVA;
    }

    public Membresia(Socio socio, Plan plan, LocalDate fechaInicio, LocalDate fechaFin,
                     EstadoMembresia estado) {
        this.socio = socio;
        this.plan = plan;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.estado = estado;
    }

    public String obtenerMembresia() {
        return "Plan: " + plan.getNombre() + " | Desde: " + fechaInicio
                + " | Hasta: " + fechaFin + " | Estado: " + estado;
    }

    // si todavia no vencio se suman los dias al final, asi no se pierden los que quedaban
    public void renovar() {
        LocalDate hoy = LocalDate.now();
        if (fechaFin.isBefore(hoy)) {
            fechaInicio = hoy;
            fechaFin = hoy.plusDays(plan.getDuracionDias());
        } else {
            fechaFin = fechaFin.plusDays(plan.getDuracionDias());
        }
        estado = EstadoMembresia.ACTIVA;
    }

    public void suspender() {
        estado = EstadoMembresia.SUSPENDIDA;
    }

    public void reactivar() {
        if (fechaFin.isBefore(LocalDate.now())) {
            estado = EstadoMembresia.VENCIDA;
        } else {
            estado = EstadoMembresia.ACTIVA;
        }
    }

    public Socio getSocio() {
        return socio;
    }

    public Plan getPlan() {
        return plan;
    }

    public LocalDate getFechaFin() {
        return fechaFin;
    }

    public EstadoMembresia getEstado() {
        return estado;
    }

    public void setEstado(EstadoMembresia estado) {
        this.estado = estado;
    }

    public String convertirALineaArchivo() {
        return socio.getDni() + ";" + plan.getIdPlan() + ";" + fechaInicio + ";" + fechaFin
                + ";" + estado;
    }
}
