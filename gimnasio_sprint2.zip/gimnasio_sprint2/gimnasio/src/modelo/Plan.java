package modelo;

public class Plan {
    private int idPlan;
    private String nombre;
    private String cantidadSemana;
    private int duracionPlan;
    private double precio;
    private EstadoPlan estado;

    public Plan(int idPlan, String nombre, String cantidadSemana, int duracionPlan, double precio) {
        this.idPlan = idPlan;
        this.nombre = nombre;
        this.cantidadSemana = cantidadSemana;
        this.duracionPlan = duracionPlan;
        this.precio = precio;
        this.estado = EstadoPlan.DISPONIBLE;
    }

    public double getPrecio() {
        return precio;
    }

    public int getDuracionDias() {
        return duracionPlan;
    }

    public void cambiarPrecio(double nuevoPrecio) {
        if (nuevoPrecio > 0) {
            precio = nuevoPrecio;
        }
    }

    public EstadoPlan getEstado() {
        return estado;
    }

    public void cambiarEstado(EstadoPlan nuevoEstado) {
        estado = nuevoEstado;
    }

    public int getIdPlan() {
        return idPlan;
    }

    public String getNombre() {
        return nombre;
    }

    public String obtenerDatos() {
        return idPlan + " - " + nombre + " - " + cantidadSemana + " - "
                + duracionPlan + " dias - $" + precio + " - " + estado;
    }

    public String convertirALineaArchivo() {
        return idPlan + ";" + nombre + ";" + cantidadSemana + ";" + duracionPlan
                + ";" + precio + ";" + estado;
    }

    public static Plan crearDesdeLinea(String linea) {
        String[] datos = linea.split(";");

        int idPlan = Integer.parseInt(datos[0]);
        String nombre = datos[1];
        String cantidadSemana = datos[2];
        int duracionPlan = Integer.parseInt(datos[3]);
        double precio = Double.parseDouble(datos[4]);

        Plan plan = new Plan(idPlan, nombre, cantidadSemana, duracionPlan, precio);
        plan.cambiarEstado(EstadoPlan.valueOf(datos[5]));
        return plan;
    }
}
