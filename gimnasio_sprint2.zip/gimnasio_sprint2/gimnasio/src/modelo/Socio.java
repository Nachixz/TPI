package modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Socio {
    public static final String[] OBJETIVOS = {"Bajar de peso", "Ganar masa muscular",
            "Mantenerse en forma", "Rehabilitacion"};

    private String nombre;
    private String apellido;
    private int dni;
    private String telefono;
    private int idSocio;
    private String email;
    private LocalDate fechaNacimiento;
    private String objetivo;
    private Membresia membresiaActual;
    private List<Membresia> membresiasAnteriores;
    private List<Asistencia> asistencias;

    public Socio(int idSocio, String nombre, String apellido, int dni, String telefono,
                 String email, LocalDate fechaNacimiento, String objetivo) {
        this.idSocio = idSocio;
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.telefono = telefono;
        this.email = email;
        this.fechaNacimiento = fechaNacimiento;
        this.objetivo = objetivo;
        this.membresiaActual = null;
        this.membresiasAnteriores = new ArrayList<>();
        this.asistencias = new ArrayList<>();
    }

    public void contratarMembresia(Plan plan, LocalDate fechaInicio) {
        // la membresia que tenia antes no se borra, queda guardada en el historial
        if (membresiaActual != null) {
            membresiasAnteriores.add(membresiaActual);
        }
        membresiaActual = new Membresia(this, plan, fechaInicio);
    }

    // se usa al leer el archivo: la ultima que se carga queda como actual y las otras van al historial
    public void cargarMembresia(Membresia membresia) {
        if (membresiaActual != null) {
            membresiasAnteriores.add(membresiaActual);
        }
        membresiaActual = membresia;
    }

    public boolean tieneMembresiaVigente() {
        if (membresiaActual == null) {
            return false;
        }
        if (membresiaActual.getFechaFin().isBefore(LocalDate.now())) {
            membresiaActual.setEstado(EstadoMembresia.VENCIDA);
        }
        return membresiaActual.getEstado() == EstadoMembresia.ACTIVA;
    }

    // devuelve la asistencia de ese dia que todavia no tiene hora de salida, o null si no hay
    public Asistencia buscarAsistenciaAbierta(LocalDate fecha) {
        for (Asistencia a : asistencias) {
            if (a.getFecha().equals(fecha) && a.tieneSalida() == false) {
                return a;
            }
        }
        return null;
    }

    public boolean registrarAsistencia(LocalDate fecha, double horaEntrada, Entrenador entrenador) {
        if (tieneMembresiaVigente() == false) {
            return false;
        }
        if (buscarAsistenciaAbierta(fecha) != null) {
            return false;
        }
        Asistencia asistencia = new Asistencia(this, fecha, horaEntrada, entrenador);
        asistencia.registrarAsistencia();
        return true;
    }

    public boolean fueAtendidoPor(Entrenador entrenador) {
        for (Asistencia a : asistencias) {
            if (a.getEntrenador() == entrenador) {
                return true;
            }
        }
        return false;
    }

    public String obtenerDatos() {
        return idSocio + " - " + apellido + ", " + nombre + " | DNI: " + dni
                + " | Tel: " + telefono + " | Email: " + email
                + " | Nacimiento: " + fechaNacimiento + " | Objetivo: " + objetivo;
    }

    public int getIdSocio() {
        return idSocio;
    }

    public int getDni() {
        return dni;
    }

    public String getObjetivo() {
        return objetivo;
    }

    public Membresia getMembresiaActual() {
        return membresiaActual;
    }

    public List<Membresia> getMembresiasAnteriores() {
        return membresiasAnteriores;
    }

    public List<Asistencia> getAsistencias() {
        return asistencias;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public void setObjetivo(String objetivo) {
        this.objetivo = objetivo;
    }

    public String convertirALineaArchivo() {
        return idSocio + ";" + nombre + ";" + apellido + ";" + dni + ";" + telefono
                + ";" + email + ";" + fechaNacimiento + ";" + objetivo;
    }

    public static Socio crearDesdeLinea(String linea) {
        String[] datos = linea.split(";");

        int idSocio = Integer.parseInt(datos[0]);
        String nombre = datos[1];
        String apellido = datos[2];
        int dni = Integer.parseInt(datos[3]);
        String telefono = datos[4];
        String email = datos[5];
        LocalDate fechaNacimiento = LocalDate.parse(datos[6]);
        String objetivo = datos[7];

        return new Socio(idSocio, nombre, apellido, dni, telefono, email, fechaNacimiento, objetivo);
    }
}
