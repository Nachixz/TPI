package modelo;

import java.time.LocalDate;

public class Validador {

    // un texto es valido si no esta vacio
    public static boolean esTextoValido(String texto) {
        return texto.trim().isEmpty() == false;
    }

    // un nombre es valido si no esta vacio y solo tiene letras y espacios
    public static boolean esNombreValido(String nombre) {
        if (esTextoValido(nombre) == false) {
            return false;
        }
        for (int i = 0; i < nombre.length(); i++) {
            char c = nombre.charAt(i);
            if (Character.isLetter(c) == false && c != ' ') {
                return false;
            }
        }
        return true;
    }

    // un DNI tiene 7 u 8 digitos
    public static boolean esDniValido(int dni) {
        return dni >= 1000000 && dni <= 99999999;
    }

    // un telefono solo tiene numeros y entre 6 y 15 digitos
    public static boolean esTelefonoValido(String telefono) {
        if (telefono.length() < 6 || telefono.length() > 15) {
            return false;
        }
        for (int i = 0; i < telefono.length(); i++) {
            if (Character.isDigit(telefono.charAt(i)) == false) {
                return false;
            }
        }
        return true;
    }

    // un email tiene algo antes del arroba, un punto despues y no tiene espacios
    public static boolean esEmailValido(String email) {
        int arroba = email.indexOf("@");
        if (arroba < 1 || email.contains(" ")) {
            return false;
        }
        if (email.indexOf("@", arroba + 1) != -1) {
            return false;
        }
        int punto = email.lastIndexOf(".");
        return punto > arroba + 1 && punto < email.length() - 1;
    }

    // la fecha de nacimiento no puede ser de hoy en adelante ni de hace mas de 110 anios
    public static boolean esFechaNacimientoValida(LocalDate fecha) {
        LocalDate hoy = LocalDate.now();
        return fecha.isBefore(hoy) && fecha.isAfter(hoy.minusYears(110));
    }
}
