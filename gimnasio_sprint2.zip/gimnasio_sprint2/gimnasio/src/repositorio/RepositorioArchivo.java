package repositorio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

// Tiene lo que es igual para todos los repositorios: leer y escribir las lineas del archivo.
// Cada repositorio hijo solo se ocupa de pasar de linea a objeto y de objeto a linea.
public abstract class RepositorioArchivo {
    private String archivo;
    private int lineasInvalidas;

    public RepositorioArchivo(String archivo) {
        this.archivo = archivo;
        this.lineasInvalidas = 0;
    }

    protected ArrayList<String> leerLineas() throws IOException {
        ArrayList<String> lineas = new ArrayList<>();
        lineasInvalidas = 0;

        File file = new File(archivo);
        if (file.exists() == false) {
            return lineas;
        }

        // al abrir el archivo dentro del try se cierra solo, aunque haya un error
        try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                if (linea.trim().isEmpty() == false) {
                    lineas.add(linea);
                }
            }
        }
        return lineas;
    }

    protected void escribirLineas(List<String> lineas) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo))) {
            for (String linea : lineas) {
                writer.write(linea);
                writer.newLine();
            }
        }
    }

    protected void contarLineaInvalida() {
        lineasInvalidas++;
    }

    public int getLineasInvalidas() {
        return lineasInvalidas;
    }

    public String getArchivo() {
        return archivo;
    }

    // guarda una copia del archivo tal como estaba, para no perder las lineas que no se pudieron leer
    public void hacerCopiaDeSeguridad() throws IOException {
        Files.copy(Paths.get(archivo), Paths.get(archivo + ".bak"), StandardCopyOption.REPLACE_EXISTING);
    }
}
