package repositorio;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import modelo.Asistencia;
import modelo.Entrenador;
import modelo.Gimnasio;
import modelo.Socio;

public class RepositorioAsistencias extends RepositorioArchivo {

    public RepositorioAsistencias(String archivo) {
        super(archivo);
    }

    public void guardarTodas(List<Socio> socios) throws IOException {
        List<String> lineas = new ArrayList<>();
        for (Socio s : socios) {
            for (Asistencia a : s.getAsistencias()) {
                lineas.add(a.convertirALineaArchivo());
            }
        }
        escribirLineas(lineas);
    }

    // en el archivo esta el DNI del socio y el numero de entrenador (0 si no habia ninguno)
    public void cargar(Gimnasio gimnasio) throws IOException {
        for (String linea : leerLineas()) {
            try {
                String[] datos = linea.split(";");

                Socio socio = gimnasio.buscarSocio(Integer.parseInt(datos[0]));
                LocalDate fecha = LocalDate.parse(datos[1]);
                double horaEntrada = Double.parseDouble(datos[2]);
                double horaSalida = Double.parseDouble(datos[3]);
                Entrenador entrenador = gimnasio.buscarEntrenador(Integer.parseInt(datos[4]));

                boolean horasValidas = horaEntrada >= 0 && horaEntrada < 24
                        && horaSalida >= 0 && horaSalida <= 24;

                if (socio != null && horasValidas) {
                    Asistencia asistencia = new Asistencia(socio, fecha, horaEntrada, horaSalida, entrenador);
                    asistencia.registrarAsistencia();
                } else {
                    contarLineaInvalida();
                }
            } catch (RuntimeException e) {
                contarLineaInvalida();
            }
        }
    }
}
