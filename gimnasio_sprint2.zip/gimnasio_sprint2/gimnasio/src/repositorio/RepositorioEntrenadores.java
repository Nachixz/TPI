package repositorio;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import modelo.Entrenador;

public class RepositorioEntrenadores extends RepositorioArchivo {

    public RepositorioEntrenadores(String archivo) {
        super(archivo);
    }

    public void guardarTodos(List<Entrenador> entrenadores) throws IOException {
        List<String> lineas = new ArrayList<>();
        for (Entrenador e : entrenadores) {
            lineas.add(e.convertirALineaArchivo());
        }
        escribirLineas(lineas);
    }

    public ArrayList<Entrenador> leerTodos() throws IOException {
        ArrayList<Entrenador> entrenadores = new ArrayList<>();

        for (String linea : leerLineas()) {
            // si la linea tiene un dato mal (letras en un numero, una fecha rota, etc.) se saltea
            try {
                entrenadores.add(Entrenador.crearDesdeLinea(linea));
            } catch (RuntimeException e) {
                contarLineaInvalida();
            }
        }
        return entrenadores;
    }
}
