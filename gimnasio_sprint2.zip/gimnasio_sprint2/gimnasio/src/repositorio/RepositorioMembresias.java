package repositorio;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import modelo.EstadoMembresia;
import modelo.Gimnasio;
import modelo.Membresia;
import modelo.Plan;
import modelo.Socio;

public class RepositorioMembresias extends RepositorioArchivo {

    public RepositorioMembresias(String archivo) {
        super(archivo);
    }

    public void guardarTodas(List<Socio> socios) throws IOException {
        List<String> lineas = new ArrayList<>();
        for (Socio s : socios) {
            // primero las anteriores y al final la actual, que es el orden en que despues se leen
            for (Membresia m : s.getMembresiasAnteriores()) {
                lineas.add(m.convertirALineaArchivo());
            }
            if (s.getMembresiaActual() != null) {
                lineas.add(s.getMembresiaActual().convertirALineaArchivo());
            }
        }
        escribirLineas(lineas);
    }

    // en el archivo esta el DNI del socio y el numero de plan, y con eso se buscan en el gimnasio
    public void cargar(Gimnasio gimnasio) throws IOException {
        for (String linea : leerLineas()) {
            try {
                String[] datos = linea.split(";");

                Socio socio = gimnasio.buscarSocio(Integer.parseInt(datos[0]));
                Plan plan = gimnasio.buscarPlan(Integer.parseInt(datos[1]));
                LocalDate fechaInicio = LocalDate.parse(datos[2]);
                LocalDate fechaFin = LocalDate.parse(datos[3]);
                EstadoMembresia estado = EstadoMembresia.valueOf(datos[4]);

                if (socio != null && plan != null) {
                    socio.cargarMembresia(new Membresia(socio, plan, fechaInicio, fechaFin, estado));
                } else {
                    contarLineaInvalida();
                }
            } catch (RuntimeException e) {
                contarLineaInvalida();
            }
        }
    }
}
