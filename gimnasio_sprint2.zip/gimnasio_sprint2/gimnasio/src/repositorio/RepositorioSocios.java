package repositorio;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import modelo.Socio;

public class RepositorioSocios extends RepositorioArchivo {

    public RepositorioSocios(String archivo) {
        super(archivo);
    }

    public void guardarTodos(List<Socio> socios) throws IOException {
        List<String> lineas = new ArrayList<>();
        for (Socio s : socios) {
            lineas.add(s.convertirALineaArchivo());
        }
        escribirLineas(lineas);
    }

    public ArrayList<Socio> leerTodos() throws IOException {
        ArrayList<Socio> socios = new ArrayList<>();

        for (String linea : leerLineas()) {
            // si la linea tiene un dato mal (letras en un numero, una fecha rota, etc.) se saltea
            try {
                socios.add(Socio.crearDesdeLinea(linea));
            } catch (RuntimeException e) {
                contarLineaInvalida();
            }
        }
        return socios;
    }
}
