package vista;

import java.util.Scanner;

public class VistaConsola {
    private Scanner sc;

    public VistaConsola() {
        this.sc = new Scanner(System.in);
    }

    public void mostrarMenu() {
        System.out.println();
        System.out.println("========== GIMNASIO ==========");
        System.out.println("--- Socios ---");
        System.out.println(" 1. Registrar socio");
        System.out.println(" 2. Consultar socio");
        System.out.println(" 3. Modificar socio");
        System.out.println("--- Planes ---");
        System.out.println(" 4. Ver planes");
        System.out.println(" 5. Cargar plan nuevo");
        System.out.println(" 6. Modificar plan");
        System.out.println("--- Membresias ---");
        System.out.println(" 7. Contratar membresia");
        System.out.println(" 8. Renovar membresia");
        System.out.println(" 9. Suspender o reactivar membresia");
        System.out.println("--- Asistencias ---");
        System.out.println("10. Registrar entrada");
        System.out.println("11. Registrar salida");
        System.out.println("12. Cancelar asistencia");
        System.out.println("--- Entrenadores ---");
        System.out.println("13. Registrar entrenador");
        System.out.println("14. Ver entrenadores");
        System.out.println("15. Buscar socios por objetivo");
        System.out.println(" 0. Salir");
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }

    // si se cierra la entrada del teclado (Ctrl+Z o Ctrl+D) el programa termina sin error.
    // No se pierde nada porque los datos se guardan despues de cada cambio.
    private String leerLinea() {
        if (sc.hasNextLine() == false) {
            System.out.println();
            System.out.println("Se cerro la entrada de datos. Fin del programa.");
            System.exit(0);
        }
        return sc.nextLine().trim();
    }

    public String leerTexto(String mensaje) {
        System.out.print(mensaje);
        String texto = leerLinea();
        // el punto y coma es el separador de los archivos, por eso no puede estar en los datos
        return texto.replace(";", ",");
    }

    public int leerEntero(String mensaje) {
        int numero = 0;
        boolean valido = false;
        while (valido == false) {
            System.out.print(mensaje);
            try {
                numero = Integer.parseInt(leerLinea());
                valido = true;
            } catch (NumberFormatException e) {
                System.out.println("Hay que ingresar un numero entero.");
            }
        }
        return numero;
    }

    public double leerDecimal(String mensaje) {
        double numero = 0;
        boolean valido = false;
        while (valido == false) {
            System.out.print(mensaje);
            String texto = leerLinea().replace(",", ".");
            // solo se aceptan numeros como 18 o 18.5 (no letras, ni negativos, ni cosas como NaN)
            if (texto.matches("[0-9]+([.][0-9]+)?")) {
                numero = Double.parseDouble(texto);
                valido = true;
            } else {
                System.out.println("Hay que ingresar un numero, por ejemplo 18 o 18.5");
            }
        }
        return numero;
    }

    // muestra las opciones numeradas y devuelve la posicion de la que se eligio
    public int elegirPosicion(String titulo, String[] opciones) {
        System.out.println(titulo);
        for (int i = 0; i < opciones.length; i++) {
            System.out.println((i + 1) + ". " + opciones[i]);
        }
        int numero = leerEntero("Opcion: ");
        while (numero < 1 || numero > opciones.length) {
            System.out.println("Opcion invalida.");
            numero = leerEntero("Opcion: ");
        }
        return numero - 1;
    }

    public String elegirDeLista(String titulo, String[] opciones) {
        return opciones[elegirPosicion(titulo, opciones)];
    }
}
